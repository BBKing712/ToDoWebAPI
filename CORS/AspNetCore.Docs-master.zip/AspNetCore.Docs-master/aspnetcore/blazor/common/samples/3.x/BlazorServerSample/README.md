# Blazor Server Sample App

This sample illustrates the use of Blazor scenarios described in the Blazor documentation.
